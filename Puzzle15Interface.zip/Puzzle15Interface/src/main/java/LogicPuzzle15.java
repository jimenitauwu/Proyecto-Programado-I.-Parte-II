import com.example.puzzle15interface.Files;
import javafx.scene.control.Button;

public class LogicPuzzle15 {

    //Declaración de variables globales

    int board[][], posEmpty; //Matriz del tablero de juego y variable que corresponde al espacio vacío de la matriz
    int RowEmpty, columnEmpty;

    public LogicPuzzle15() {

        board = new int[4][4];

        //do {
        startBoard();
        //while (gamefinish() == true);


    }

    //este método inicializa el tablero dejando el espacio en blanco y asignando los números del 1 al 15
    public void startBoard(){

        //Determina el valor aleatorio de la posición vacía que va a tomar en la matriz
        posEmpty = (int)(Math.random() * 16);

        int posNumber;

        for(int k = 1; k<=15; k++){ //k es el número a colocar en el tablero(números del 1 al 15)

            posNumber=(int) (Math.random()* 16); //Genera la posición aleatoria de donde colocar k

            //Buscar espacio disponible para la variable posNumber
            while (posNumber == posEmpty || board[posNumber/4][posNumber % 4] != 0)
                posNumber = (posNumber + 1) % 16;


            //Asignar el valor de k en la posición de la matriz

            board[posNumber/4][posNumber%4]= k;

        }

        //Con estas variables el programa reconoce la posición exacta en la que se encuentra el 0 en el tablero, para que el método MakePlay pueda reconocer cuáles jugadas son admitidas en el juego
        RowEmpty = posEmpty/4;
        columnEmpty = posEmpty%4;

    }

    public void printBoard(){

        for(int row= 0; row < 4; row++){

            for(int colum = 0; colum < 4; colum++)

                if (board[row][colum]>=10)

                    System.out.print(board[row][colum] + " ");

                else System.out.print(" "+board[row][colum] + " ");



            System.out.println();
        }//End for row


    }


    public boolean GameOver() {

        int value = 1;//Variable que determina si el juego ha terminado o no, va cambiando conforme aumenta el valor de las filas y las columnas

        for (int i = 0; i < 4; i++) //Volver a recorrer la matriz

            for (int j = 0; j < 4; j++) {

                //Elegir el valor exactamente como lo pide el usuario

                if (value == 16) //Condición para que cuando el usuario haya completado el juego, haya ordenado todos los números del 1 hasta el 15, no siga recorriendo el ciclo y que tire el mensaje "Ganaste el juego"

                    return true;


                //La variable valor es la que indica si el número que se encuentra en la casilla de la fila y la columna que el usuario puso en el JOptionPane es igual al valor que debería dar en orden del 1 al 15

                //Ejemplo: si el usuario puso que quería mover el número de la Fila 0, columna 0 a la derecha (en el vacío), este debería ser un dos para que coincida con la variable valor, osea, es la que indica si el orden de los números del tablero está correcta

                //Con la matriz del tablero, se le asignan los parámetros proporcionados por el usuario

                if (board[i][j] != value)  //la matriz debe ser diferente a valor, esto significa que todavía el juego no ha terminado, y que el programa debe seguir solicitando los valores de la fila-columna hasta que se cumpla la igualdad

                    return false; //Retorna falso porque no se ha cumplido con la condicion del if que indica si el valor es igual a 16


                value++; //Se aumenta la variable valor, porque sino seguirá valiendo el mismo número y nunca terminaría el ciclo
            }

        return true;
    }

    public void MakePlay(int i, int j) { //Este método requiere del método booleano validMoves, ya que, se debe verificar si la jugada que desea realizar el usuario es permitida o no para el juego


        if (validMoves(i, j)) {//Pregunta si el método booleano es verdadero, para que se realice el intercambio de posiciones

            board[RowEmpty][columnEmpty] = board[i][j];//Se hace el intercambio de posición, quiere decir que si el usuario desea mover un número al vacío, esta condición permite que se muestre en el tablero dicho cambio que se realizo (solo sucede si el movimiento que hace es válido)

            board[i][j] = 0;//Se hace el mismo intercambio, se coloca el 0 donde se encontraba el número que el usuario solicitó mover

            RowEmpty = i;//Se actualizan las variables de la casilla vacía, para saber en que lugar se encuentran posicionadas

            columnEmpty = j;//Posición que se encuentra el vacío con respecto a las columnas

        }else
            System.out.println("Movimiento no valido, intentelo denuevo");//Tira el mensaje cuando el usuario hace una jugada inválida


    }

    public boolean validMoves (int i, int j) { //Se le pasa como parámetro la fila y la columna proporcionada por el usuario

        int RowDifference = i - RowEmpty;//Se debe restar la fila que seleccionó el usuario, con la fila en la que se encuentra la casilla vacía
        int columnDifference = j - columnEmpty;//Se debe restar la columna que seleccionó el usuario, con la columna en la que se encuentra la casilla vacía


        if (RowDifference == 1 && columnDifference == 0)

             /*Si la resta que se efectuó en la variable "filaDiferencia" es igual a 1 (Ejemplo: El usuario desea mover el número de la fila 2, columna 3; y la casilla vacía se ubica en la fila 1 columna 3) significa que la casilla
        seleccionada esta debajo de la casilla vacía y si columnaDiferencia es igual a 0 (columna seleccionada: 3 - columna del vacío= 3= 0) significa que no hay movimiento horizontal. El número se mueve hacia arriba
         */
            //Movimiento hacia arriba

            return true;

        else if (RowDifference == 0 && columnDifference == 1)

            /*Si la resta que se efectuó en la variable "filaDiferencia" es igual a 0 (Ejemplo: El usuario desea mover el número de la fila 2, columna 3; y la casilla vacía se ubica en la fila 2 columna 2) significa que la casilla
        seleccionada esta al lado derecho de la casilla vacía y si columnaDiferencia es igual a 1 (columna seleccionada: 3 - columna del vacio= 2= 1) significa que no hay movimiento vertical. El número se mueve hacia la izquierda
         */
            //Movimiento hacia izquierda

            return true;

        else if (RowDifference == -1 && columnDifference == 0)

             /*Si filaDiferencia es igual a -1 significa que la casilla seleccionada está justo arriba
        y columnaDiferencia es igual a 0 significa que no hay movimiento horizontal
         */
            //Movimiento hacia abajo

            return true;

        else if (RowDifference == 0 && columnDifference == -1)

             /*Si la resta que se efectuó en la variable "filaDiferencia" es igual a 0 (Ejemplo: El usuario desea mover el número de la fila 2, columna 2; y la casilla vacía se ubica en la fila 2 columna 3) significa que la casilla
        seleccionada está al lado izquierdo de la casilla vacía y si columnaDiferencia es igual a -1 (columna seleccionada: 2 - columna del vacío: 3= -1) significa que no hay movimiento vertical. El número se mueve hacia la derecha
         */
            //MOvimiento a la derecha

            return true;



        return false;
    }



}
