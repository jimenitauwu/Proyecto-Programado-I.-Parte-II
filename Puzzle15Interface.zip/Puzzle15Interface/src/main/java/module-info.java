module com.example.puzzle15interface {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.puzzle15interface to javafx.fxml;
    exports com.example.puzzle15interface;
}