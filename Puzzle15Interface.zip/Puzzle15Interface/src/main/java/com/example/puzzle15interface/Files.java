package com.example.puzzle15interface;

import javafx.scene.control.Button;

public class Files {

        private Button btN_Files;


        public Files (Button btN_Files) {
            this.btN_Files = btN_Files;

        }

        public Button getBtN_Files() {
            return btN_Files;
        }

        public void setBtN_Files (Button btN_Files) {
            this.btN_Files = btN_Files;
        }

}
