import com.example.puzzle15interface.Files;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class InterfacePuzzle15 {

    LogicPuzzle15 lP= new LogicPuzzle15();

    public Scene getScene() {

        GridPane gP_Grid = new GridPane();
        gP_Grid.setHgap(10);
        gP_Grid.setVgap(10);

        Label lb_tittle = new Label("Fifteen Puzzle Game");
        lb_tittle.setMaxSize(450, 100);
        lb_tittle.setFont(Font.font("Britannic Bold", FontWeight.EXTRA_BOLD, 20));
        lb_tittle.setTextFill(Color.BLACK);
        lb_tittle.setAlignment(Pos.CENTER);




        public  int [][] ButtonsGame() {

            for(int f=0; f< lP.board.length; f++){

                for(int c=0; c<lP.board[0].length; c++) {

                    Button bTN_Files = new Button();

                    lP.board[f][c] = new Files(bTN_Files);

                    lP.board[f][c].getBtN_Files().setOnAction(event -> {

                    });

                    gP_Grid.add(lP.board[f][c].getBtN(),c,f);
                }
            }


        return getScene();
    }






}
